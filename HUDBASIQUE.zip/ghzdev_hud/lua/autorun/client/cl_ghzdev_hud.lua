/*---------------------------------------------------------
			Addons By GHZDEV

	Site:	https://ghzdev.eu/
	Steam:  https://steamcommunity.com/id/GHZDEV/
---------------------------------------------------------*/

--Désactivé L'HUD de base 
hook.Add("HUDPaint", "DarkRP_Mod_HUDPaint", hudPaint)

hook.Add( "HUDShouldDraw", "Remove default", function( name ) 
    if ( name == "CHudHealth" or name == "CHudBattery" or name == "CHudAmmo" ) then
        return false
    end
end )

hook.Add("HUDDrawTargetID", "HMHUD", function()
    return
end)


local HideElementsTable = {
   
    -- DarkRP
    ["DarkRP_HUD"]              = true,
    ["DarkRP_ArrestedHUD"]      = false,
    ["DarkRP_EntityDisplay"]    = false,
    ["DarkRP_ZombieInfo"]       = true,
    ["DarkRP_LocalPlayerHUD"]   = true,
    ["DarkRP_Hungermod"]        = true,
    ["DarkRP_Agenda"]           = true,

    -- Sandbox
    ["CHudHealth"]              = true,
    ["CHudBattery"]             = true,
    ["CHudSuitPower"]           = true,

}

local function HideElements( element )
    if HideElementsTable[ element ] then
        return false
    end
end
hook.Add( "HUDShouldDraw", "HideElements", HideElements )

--Police d'écriture
surface.CreateFont( "police-1", {
	font = "police-1",
	extended = false,
	size = 21,
	weight = 400,
	blursize = 0,
	scanlines = 0,
	antialias = true,
	underline = false,
	italic = false,
	strikeout = false,
	symbol = false,
	rotary = false,
	shadow = false,
	additive = false,
	outline = false,
} )

--HUD
hook.Add("HUDPaint", "GHZHUD", function()
local health = LocalPlayer():Health()
local armor = LocalPlayer():Armor()
local food = LocalPlayer():getDarkRPVar("Energy")

local job = team.GetName(LocalPlayer():Team())
local salary = LocalPlayer():getDarkRPVar("salary")
local money = LocalPlayer():getDarkRPVar("money")
local name = LocalPlayer():Name()

--Le model de l'HUD
draw.RoundedBox(0, 5, ScrH() - 150, 350, 145, Color(22,19,19,255))
draw.RoundedBox(0, 5, ScrH() - 175, 350, 25, Color(234,4,4,255))

--deuxième box de la vie , armure et faim
draw.RoundedBox(6, 10, ScrH() - 25, 340, 14, Color(50,50,52,255))
draw.RoundedBox(6, 10, ScrH() - 43, 340, 14, Color(50,50,52,255))
draw.RoundedBox(6, 10, ScrH() - 60, 340, 14, Color(50,50,52,255))

--première box de la vie , armure et faim 
draw.RoundedBox(6, 10, ScrH() - 25, health * 3.4, 14, Color(164,13,13,255))
draw.RoundedBox(6, 10, ScrH() - 43, armor * 3.4, 14, Color(0,47,255,255))
draw.RoundedBox(6, 10, ScrH() - 60,  food * 3.4, 14, Color(28, 196, 1,255))

--Les textes qui s'affiche dans la HUD pour la vie ect...
--draw.SimpleText(health, "police-1", 168, ScrH() - 84, Color(214,204,204))
--draw.SimpleText(armor, "police-1", 168, ScrH() - 62, Color(214,204,204))
draw.SimpleText("Le nom de votre Serveur", "police-1", 12, ScrH() - 173, Color(214,204,204))

draw.SimpleText("Salaire: ".. salary.. "€ ", "police-1", 205, ScrH() - 120, Color (255,255,255))
draw.SimpleText("Argent: ".. money.. "€ ", "police-1", 205, ScrH() - 145, Color (255,255,255))
draw.SimpleText("Job: ".. job, "police-1", 10, ScrH() - 120, Color (255,255,255))
draw.SimpleText("Nom: ".. name, "police-1", 10, ScrH() - 145, Color (255,255,255))

end)
		 
--Notification
local function DisplayNotify(msg)
    local txt = msg:ReadString()
    GAMEMODE:AddNotify(txt, msg:ReadShort(), msg:ReadLong())
    surface.PlaySound("buttons/lightswitch2.wav")
    MsgC(Color(255, 20, 20, 255), "[ghzdev] ", Color(200, 200, 200, 255), txt, "\n")
end